<div class=" row">
    <div class="text-center">
        <h3>Blood Group</h3>
        <div class="container">
            <div class="list-group">

                <a href="<?php echo base_url('welcome/a_positive')?>" class="list-group-item list-group-item-action">A Positive</a>
                <a href="<?php echo base_url('welcome/a_negative')?>" class="list-group-item list-group-item-action">A Negative</a>
                <a href="<?php echo base_url('welcome/b_positive')?>" class="list-group-item list-group-item-action">B Positive</a>
                <a href="<?php echo base_url('welcome/b_negative')?>" class="list-group-item list-group-item-action">B Negative</a>
                <a href="<?php echo base_url('welcome/o_positive')?>" class="list-group-item list-group-item-action">O Positive</a>
                <a href="<?php echo base_url('welcome/o_negative')?>" class="list-group-item list-group-item-action">O Negative</a>
                <a href="<?php echo base_url('welcome/ab_positive')?>" class="list-group-item list-group-item-action">AB Positive</a>
                <a href="<?php echo base_url('welcome/ab_negative')?>" class="list-group-item list-group-item-action">AB Negative</a>
            </div>
        </div>
    </div>
</div>